package vmdv.paint.graph;

public class Edge {
	public String from;
	public String to;
	
	public Edge(String from, String to) {
		this.from = from;
		this.to = to;
	}
}
