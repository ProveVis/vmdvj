package vmdv.paint.listener;

public interface EdgeInfo {

}
