package vmdv.paint.treeViewer;

public class HighlightSubtreePopup extends PopupItem {

	public HighlightSubtreePopup(String l) {
		super(l);
	}

	@Override
	public void action(TreeVisualizer tv) {
		// TODO Auto-generated method stub
//		tv.listener.addAffect(new HighlightSameSubtreeAffect(tv.tree));
	}

}
