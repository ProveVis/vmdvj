package vmdv.paint.treeViewer;

import com.jogamp.opengl.GLAutoDrawable;

public interface AssistAffect {
	public void affect(GLAutoDrawable gld);
}
